#!/bin/sh
#edit cd path below to match pyching program directory 
cd /usr/share/pyching
exec ./pyching.py "$@"
